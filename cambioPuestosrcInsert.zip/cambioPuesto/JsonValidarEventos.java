/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package mx.edu.cobaqroo.personal.gestion.cambioPuesto;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mx.edu.cobaqroo.proyectoBase.clases.Conectar;
import mx.edu.cobaqroo.proyectoBase.clases.utilerias;

/**
 *
 * @author elisa
 */

@WebServlet(name = "JsonValidarEventos", urlPatterns = {"/personal.gestion.cambioPuesto/JsonValidarEventos"})
public class JsonValidarEventos extends HttpServlet {

    // QUE NO EXISTA UN PUESTO FUTURO 
    public static boolean coincideConOtro(Date fechaAplicacion, Date fechaAsignada, Date fechaFinal, Connection conexion) throws SQLException, Exception {

        boolean coincide = false;

        if (fechaFinal != null) { // si tiene fecha vencimiento la mandamos para comparar
            // si la fecha de aplicacion es igual o anterior a la fecha de vencimiento del registro, coincide (true)
            coincide = fechaAplicacion.before(fechaFinal) || fechaAplicacion.equals(fechaFinal);
        } else if (fechaAsignada != null) { // sino, usamos la fecha asignada
            // si la fecha de aplicacion es igual o anterior a la fecha asignada del registro, coincide (true)
            coincide = fechaAplicacion.before(fechaAsignada) || fechaAplicacion.equals(fechaAsignada);
        } else { // si no tiene ambas, en caso especial, permitiremos guardar
            coincide = false;
        }

        return coincide;
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter(); Connection conexion = Conectar.getConexionRH()) {
            try {

                SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");

                int bandera = utilerias.parseInt(request, "bandera", -1);
                String fechaFinal = utilerias.parseString(request, "fechaFinal");
                String fechaAsignada = utilerias.parseString(request, "fechaAsignada");
                String fechaAplicacion = utilerias.parseString(request, "fechaAplicacion");

                Date dateAsignada = null;
                Date dateFinal = null;
                Date dateAplicacion = formato.parse(fechaAplicacion);  // yy-MM-dd

                if (bandera == 0) {
                    out.print(false);
                } else {
                    if (!"null".equals(fechaFinal)) { // dd-mm-yy 
                        dateFinal = utilerias.parseDate(fechaFinal, "-"); // yy-MM-dd
                    } else {
                      dateFinal = null;  
                    }
                    
                    if(!"null".equals(fechaAsignada)){ // dd-mm-yy
                        dateAsignada = utilerias.parseDate(fechaAsignada, "-");  // yy-MM-dd
                    }else{
                        dateAsignada = null;
                    }
                    
                    out.print(coincideConOtro(dateAplicacion, dateAsignada, dateFinal, conexion));
                }

            } catch (Exception e) {
                response.setStatus(400);
                out.print("{\"error\":\"" + e.getMessage() + "\"}");
            }
        } catch (Exception e) {

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

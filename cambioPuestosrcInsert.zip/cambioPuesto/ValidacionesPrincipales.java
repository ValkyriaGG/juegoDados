/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mx.edu.cobaqroo.personal.gestion.cambioPuesto;

import java.util.Date;

/**
 *
 * @author elisa
 */
public class ValidacionesPrincipales {
    
    public boolean noEsDocente;
    public boolean adscripcionActiva;
    public boolean definitividadActiva;
    public int IdPEORecibida;



    public int getIdPEORecibida() {
        return IdPEORecibida;
    }

    public void setIdPEORecibida(int IdPEORecibida) {
        this.IdPEORecibida = IdPEORecibida;
    }
    public int IdPEOReciente;

    public int getIdPEOReciente() {
        return IdPEOReciente;
    }

    public void setIdPEOReciente(int IdPEOReciente) {
        this.IdPEOReciente = IdPEOReciente;
    }
  

    public ValidacionesPrincipales() {
    }

    public boolean isNoEsDocente() {
        return noEsDocente;
    }

    public void setNoEsDocente(boolean noEsDocente) {
        this.noEsDocente = noEsDocente;
    }

    public boolean isAdscripcionActiva() {
        return adscripcionActiva;
    }

    public void setAdscripcionActiva(boolean adcripcionActiva) {
        this.adscripcionActiva = adcripcionActiva;
    }

    public boolean isDefinitividadActiva() {
        return definitividadActiva;
    }

    public void setDefinitividadActiva(boolean definitividadActiva) {
        this.definitividadActiva = definitividadActiva;
    }
    
    
    
}

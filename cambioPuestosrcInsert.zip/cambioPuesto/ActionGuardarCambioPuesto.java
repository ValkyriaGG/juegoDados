
package mx.edu.cobaqroo.personal.gestion.cambioPuesto;

import com.edu.cobaqroo.empleados.clases.PersonaPuesto;
import com.edu.cobaqroo.empleados.contrataciones.Archivo;
import com.edu.cobaqroo.empleados.contrataciones.SecuenciaProceso;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import mx.edu.cobaqroo.login.IdentidadBean;
import mx.edu.cobaqroo.proyectoBase.clases.Conectar;
import mx.edu.cobaqroo.proyectoBase.clases.utilerias;
import mx.edu.cobaqroo.proyectoBase.sql.DBTable;

/**
 *
 * @author elisa
 */
@WebServlet(name = "ActionGuardarCambioPuesto", urlPatterns = {"/personal.gestion.cambioPuesto/ActionGuardarCambioPuesto"})
@MultipartConfig
public class ActionGuardarCambioPuesto extends HttpServlet {

    public void bajaPuestosActivos(int IdPEO, int IdPersona, Date FechaFinal, Connection conexion) throws SQLException {

        PreparedStatement consulta;
        consulta = conexion.prepareStatement("UPDATE PersonaPuesto SET IdPersonaPuestoSituacion = 2, FechaFinal = ? WHERE IdPersonalEstructuraOrganizacional=? AND IdPersona =? AND IdPersonaPuestoSituacion = 1");
        consulta.setDate(1, new java.sql.Date(FechaFinal.getTime()));
        consulta.setInt(2, IdPEO);
        consulta.setInt(3, IdPersona);

        consulta.executeUpdate();
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter(); Connection conexion = Conectar.getConexionRH(); Connection con195 = Conectar.getConexionDocumentosDocente()) {
            try {

                PersonaPuesto puesto = new PersonaPuesto();
                conexion.setAutoCommit(false);
                //con195.setAutoCommit(false);

                // variables extraidas desde el js 
                int IdPersonaPuesto = utilerias.parseInt(request, "IdPersonaPuesto", -1);
                int IdPersonalEstructuraOrganizacional = utilerias.parseInt(request, "IdPEO", -1);

                int IdPersona = utilerias.parseInt(request, "IdPersona", -1);
                int IdTipoPersona = utilerias.parseInt(request, "puesto", -1);
                int IdPuestoTitularidad = utilerias.parseInt(request, "funcion", -1);
                int IdNivelUnidadAdministrativa = utilerias.parseInt(request, "nivel", -1);
                // variable de la fecha de aplicacion registrada
                String fechaAplicacion = request.getParameter("fechaAplicacion");
                SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
                Date app_date = formato.parse(fechaAplicacion);

                // variable identidad para saber quien registra
                IdentidadBean identidad = (IdentidadBean) request.getSession().getAttribute("identidad");
                
                // json que almacena los registros que se modificaron para usarlos en una cancelacion
                String descripcion = utilerias.parseString(request, "descripcion");

                // datos del archivo
                Part part = request.getPart("archivo");
                Archivo file = new Archivo();
                file.parseFrom(part);
                
                // actualizar 
                if (IdPersonaPuesto != -1) {
                    puesto.IdPersonaPuesto = IdPersonaPuesto;
                    puesto.IdPuestoTitularidad = IdPuestoTitularidad;
                    puesto.IdNivelUnidadAdministrativa = IdNivelUnidadAdministrativa;
                    puesto.FechaMovimiento = new Timestamp(utilerias.getFechaActual().getTime());

                    //DBTable.factory(puesto, conexion).getUpdate().execute();
                    
                } else { // agregar un cambio de puesto
                    
                    puesto.IdPersona = IdPersona;
                    puesto.FechaAsignacion = app_date;
                    puesto.IdTipoPersona = IdTipoPersona;
                    puesto.IdPuestoTitularidad = IdPuestoTitularidad;
                    puesto.IdNivelUnidadAdministrativa = IdNivelUnidadAdministrativa;
                    puesto.IdPersonaRegistro = identidad.getIdPersona();
                    puesto.IdPersonaPuestoSituacion = 1;
                    puesto.IdPersonalEstructuraOrganizacional = IdPersonalEstructuraOrganizacional;
                    puesto.FechaRegistro = new Timestamp(utilerias.getFechaActual().getTime());
                    
                    bajaPuestosActivos(IdPersonalEstructuraOrganizacional, IdPersona, utilerias.addDays(app_date, -1), conexion);
                    DBTable.factory(puesto, conexion).getInsert().execute();

                    puesto.IdPersonaPuesto = utilerias.getLastInsertId(conexion);

                    // GUARDAR ARCHIVO
                    PersonaPuestoArchivo archivo = new PersonaPuestoArchivo();
                    archivo.Archivo = file.ContenidoFile;
                    archivo.NombreArchivo = file.NameFile;
                    archivo.FechaHoraRegistro = new Timestamp(utilerias.getFechaActual().getTime());
                    archivo.IdPersonaPuesto = puesto.getIdPersonaPuesto();
                    archivo.IdPersonaRegistro =  identidad.getIdPersona();
                    archivo.ComentarioDocumento = "Cambio de puesto IdPEO: " + IdPersonalEstructuraOrganizacional;
                    DBTable.factory(archivo, con195).getInsert().execute();

                    // GUARDAR EN SECUENCIA PROCESO
                    SecuenciaProceso secuencia = new SecuenciaProceso();
                    secuencia.IdProceso = 10;
                    secuencia.IdActor = 2;
                    secuencia.IdEstado = 4;
                    secuencia.ConsecutivoSecuencia = 1;
                    secuencia.FechaHoraRegistro = new Timestamp(utilerias.getFechaActual().getTime());
                    secuencia.IdNumeroIdentificaProceso = puesto.getIdPersonaPuesto();
                    secuencia.IdPersona = IdPersona;
                    secuencia.IdPersonaRegistro = identidad.getIdPersona();
                    secuencia.Descripcion = descripcion;
                    DBTable.factory(secuencia, conexion).getInsert().execute();
                }
                conexion.commit();

            } catch (Exception e) {
                utilerias.rollback(conexion);
                response.setStatus(400);
                out.print("{\"error\":\"" + e.getMessage() + "\"}");
            }
        } catch (Exception e) {

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

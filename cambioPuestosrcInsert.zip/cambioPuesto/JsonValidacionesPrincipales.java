/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package mx.edu.cobaqroo.personal.gestion.cambioPuesto;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mx.edu.cobaqroo.proyectoBase.clases.Conectar;
import mx.edu.cobaqroo.proyectoBase.clases.utilerias;

/**
 *
 * @author elisa
 */
@WebServlet(name = "JsonValidacionesPrincipales", urlPatterns = {"/personal.gestion.cambioPuesto/JsonValidacionesPrincipales"})
public class JsonValidacionesPrincipales extends HttpServlet {

    public static int idPEOReciente(int idPersona, Connection conexion) throws SQLException {
        int idpeoreciente = 0;
        PreparedStatement consulta = null;
        ResultSet respuesta = null;

        consulta = conexion.prepareStatement("SELECT MAX(IdPersonalEstructuraOrganizacional) as IdPEOReciente, MAX(FechaAlta) as FechaAlta FROM PersonalEstructuraOrganizacional WHERE IdPersona = ?");
        consulta.setInt(1, idPersona);
        respuesta = consulta.executeQuery();

        if (respuesta.next()) {
            idpeoreciente = respuesta.getInt("IdPEOReciente");
        }
        return idpeoreciente;
    }

    public static boolean esDocente(int plantilla_id, Connection conexion) throws SQLException {
        boolean noesDocente = false;
        PreparedStatement consulta;
        consulta = conexion.prepareStatement("SELECT IF((SELECT IdAnaliticoTipoPersona FROM PersonalPlantilla WHERE IdPersonaPlantilla =?)!=3,\"TRUE\",\"FALSE\") AS noEsDocente");
        consulta.setInt(1, plantilla_id);

        ResultSet respuesta = consulta.executeQuery();
        if (respuesta.next()) {
            // Utilizar equals para comparar la cadena
            noesDocente = "TRUE".equals(respuesta.getString("noEsDocente")); // Cambiado a true ya que "noEsDocente" debería ser verdadero para no ser docente  (IdAnalitico =! 3)
        }
        return noesDocente;
    }

    public static boolean adscripcionesActivas(int IdPEO, Connection conexion) throws SQLException {
        boolean adscripcionActiva = false;
        PreparedStatement consulta;
        consulta = conexion.prepareStatement("SELECT IF((SELECT COUNT(*) FROM PersonalEstructuraOrganizacional WHERE IdPersonalEstructuraOrganizacional =? AND IdSituacionPersonalEstructuraOrganizacional = 1 HAVING COUNT(*)) = 1,\"TRUE\",\"FALSE\") AS AdscripcionActiva");
        consulta.setInt(1, IdPEO);

        ResultSet respuesta = consulta.executeQuery();
        if (respuesta.next()) {
            // Utilizar equals para comparar la cadena
            adscripcionActiva = "TRUE".equals(respuesta.getString("AdscripcionActiva")); // Cambiado a true ya que "AdscripcionActiva" debería ser verdadero para tener 1 activa, si tiene mas debe notificarse
        }
        return adscripcionActiva;
    }

    public static boolean definitividadActiva(int IdPEO, Connection conexion) throws SQLException {
        boolean definitividad = false;
        PreparedStatement consulta;
        consulta = conexion.prepareStatement("SELECT IF((SELECT COUNT(*) FROM PersonalCategoria WHERE IdPersonalEstructuraOrganizacional =? AND IdTipoSituacionCategoria = 1 AND IdTipoMovimientoCategoria = 7 GROUP BY IdPersonalEstructuraOrganizacional HAVING COUNT(*))=1,\"TRUE\",\"FALSE\") AS definitividadActiva");
        consulta.setInt(1, IdPEO);

        ResultSet respuesta = consulta.executeQuery();
        if (respuesta.next()) {
            // Utilizar equals para comparar la cadena
            definitividad = "TRUE".equals(respuesta.getString("definitividadActiva")); // Cambiado a true ya que "definitividadActiva" debería ser verdadero para tener 1 categoria activa, si tiene mas ese PEO debe notificarse
        }
        return definitividad;
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter(); Connection conexion = Conectar.getConexionRH();) {
            try {

                ValidacionesPrincipales validaciones = new ValidacionesPrincipales();

                int IdPlantilla = utilerias.parseInt(request, "IdPlantilla", -1);
                int IdPersona = utilerias.parseInt(request, "IdPersona", -1);
                int IdPEO = utilerias.parseInt(request, "IdPEO", -1);

                validaciones.setNoEsDocente(esDocente(IdPlantilla, conexion));
                validaciones.setAdscripcionActiva(adscripcionesActivas(idPEOReciente(IdPersona, conexion), conexion));
                validaciones.setDefinitividadActiva(definitividadActiva(idPEOReciente(IdPersona, conexion), conexion));
                validaciones.setIdPEOReciente(idPEOReciente(IdPersona, conexion));
                validaciones.setIdPEORecibida(IdPEO);
               
                // SI no es docente, tiene una adscripcion activa y una definitividad activa, incluyendo una sola categoria = 1 (activo), puede continuar
                out.print(utilerias.toJson(validaciones));

            } catch (Exception e) {
                response.setStatus(400);
                out.print("{\"error\":\"" + e.getMessage() + "\"}");
            }
        } catch (Exception e) {

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

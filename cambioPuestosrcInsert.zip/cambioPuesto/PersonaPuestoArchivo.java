/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mx.edu.cobaqroo.personal.gestion.cambioPuesto;

import java.util.Date;
import javax.servlet.http.Part;
import mx.edu.cobaqroo.proyectoBase.clases.utilerias;

/**
 *
 * @author elisa
 */
public class PersonaPuestoArchivo {

    public int IdPersonaPuestoArchivo;
    public int IdPersonaPuesto;
    public byte[] Archivo;
    public Date FechaHoraRegistro;
    public int IdPersonaRegistro;
    public String ComentarioDocumento;
    public String NombreArchivo;

    
    public PersonaPuestoArchivo() {
    }

    public PersonaPuestoArchivo(int IdPersonaPuestoArchivo, int IdPersonaPuesto, byte[] Archivo, Date FechaHoraRegistro, int IdPersonaRegistro, String ComentarioDocumento, String NombreArchivo) {
        this.IdPersonaPuestoArchivo = IdPersonaPuestoArchivo;
        this.IdPersonaPuesto = IdPersonaPuesto;
        this.Archivo = Archivo;
        this.FechaHoraRegistro = FechaHoraRegistro;
        this.IdPersonaRegistro = IdPersonaRegistro;
        this.ComentarioDocumento = ComentarioDocumento;
        this.NombreArchivo = NombreArchivo;
    }

    public int getIdPersonaPuestoArchivo() {
        return IdPersonaPuestoArchivo;
    }

    public void setIdPersonaPuestoArchivo(int IdPersonaPuestoArchivo) {
        this.IdPersonaPuestoArchivo = IdPersonaPuestoArchivo;
    }

    public int getIdPersonaPuesto() {
        return IdPersonaPuesto;
    }

    public void setIdPersonaPuesto(int IdPersonaPuesto) {
        this.IdPersonaPuesto = IdPersonaPuesto;
    }

    public byte[] getArchivo() {
        return Archivo;
    }

    public void setArchivo(byte[] Archivo) {
        this.Archivo = Archivo;
    }

    public Date getFechaHoraRegistro() {
        return FechaHoraRegistro;
    }

    public void setFechaHoraRegistro(Date FechaHoraRegistro) {
        this.FechaHoraRegistro = FechaHoraRegistro;
    }

    public int getIdPersonaRegistro() {
        return IdPersonaRegistro;
    }

    public void setIdPersonaRegistro(int IdPersonaRegistro) {
        this.IdPersonaRegistro = IdPersonaRegistro;
    }

    public String getComentarioDocumento() {
        return ComentarioDocumento;
    }

    public void setComentarioDocumento(String ComentarioDocumento) {
        this.ComentarioDocumento = ComentarioDocumento;
    }

    public String getNombreArchivo() {
        return NombreArchivo;
    }

    public void setNombreArchivo(String NombreArchivo) {
        this.NombreArchivo = NombreArchivo;
    }
    
    public void parseFrom(Part file) throws Exception{
        this.Archivo = utilerias.toByteArray(file.getInputStream());
        this.NombreArchivo = file.getSubmittedFileName();
    };

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package mx.edu.cobaqroo.personal.gestion.cambioPuesto;

import com.edu.cobaqroo.empleados.contrataciones.SecuenciaProceso;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mx.edu.cobaqroo.login.IdentidadBean;
import mx.edu.cobaqroo.proyectoBase.clases.Conectar;
import mx.edu.cobaqroo.proyectoBase.clases.utilerias;
import mx.edu.cobaqroo.proyectoBase.sql.DBTable;

/**
 *
 * @author elisa
 */
@WebServlet(name = "ActionSecuenciaProceso", urlPatterns = {"/personal.gestion.cambioPuesto/ActionSecuenciaProceso"})
public class ActionSecuenciaProceso extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter(); Connection conexion = Conectar.getConexionRH()) {
            try {
                
                SecuenciaProceso proceso = new SecuenciaProceso();

                int bandera = utilerias.parseInt(request, "bandera", -1);
                int IdPersona = utilerias.parseInt(request, "IdPersona", -1);
                int IdPersonaPuesto = utilerias.parseInt(request, "IdPersonaPuesto", -1);
                String descripcion = request.getParameter("fechaAplicacion");
                // variable identidad para saber quien registra
                IdentidadBean identidad = (IdentidadBean) request.getSession().getAttribute("identidad");

                // variable de la fecha de aplicacion registrada
                if (bandera != -1) { // indica que ha sido un proceso de registro

                    proceso.IdProceso = 10;
                    proceso.IdActor = 2;
                    proceso.IdEstado = 4;
                    proceso.ConsecutivoSecuencia = 1;
                    proceso.FechaHoraRegistro = new Timestamp(utilerias.getFechaActual().getTime());
                    proceso.IdNumeroIdentificaProceso = IdPersonaPuesto;
                    proceso.IdPersona = IdPersona;
                    proceso.IdPersonaRegistro = identidad.getIdPersona();
                    proceso.Descripcion = descripcion;

                } else { // indica que es un proceso de cancelacion
                    proceso.IdProceso = 10;
                    proceso.IdActor = 2;
                    proceso.IdEstado = 9;
                    proceso.ConsecutivoSecuencia = 1;
                    proceso.FechaHoraRegistro = new Timestamp(utilerias.getFechaActual().getTime());
                    proceso.IdNumeroIdentificaProceso = IdPersonaPuesto;
                    proceso.IdPersona = IdPersona;
                    proceso.IdPersonaRegistro = identidad.getIdPersona();
                    proceso.Descripcion = "Cambio de puesto cancelado por " + identidad.getNombreCompleto() + " -> " + descripcion;
                }
                //DBTable.factory(proceso, conexion).getInsert().execute();

            } catch (Exception e) {
                response.setStatus(400);
                out.print("{\"error\":\"" + e.getMessage() + "\"}");
            }
        } catch (Exception e) {

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

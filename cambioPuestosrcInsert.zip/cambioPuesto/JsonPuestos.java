/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package mx.edu.cobaqroo.personal.gestion.cambioPuesto;

import com.edu.cobaqroo.empleados.clases.PersonaPuesto;
import com.edu.cobaqroo.empleados.clases.PersonalEstructuraOrganizacional;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import mx.edu.cobaqroo.proyectoBase.clases.Conectar;
import mx.edu.cobaqroo.proyectoBase.clases.utilerias;
import mx.edu.cobaqroo.proyectoBase.sql.DBTable;

/**
 *
 * @author elisa
 */
@WebServlet(name = "JsonPuestos", urlPatterns = {"/personal.gestion.cambioPuesto/JsonPuestos"})
public class JsonPuestos extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       try (PrintWriter out = response.getWriter(); Connection conexion = Conectar.getConexionRH();) {
            try {
                PreparedStatement consulta;
                int IdPEO = utilerias.parseInt(request,"IdPEO",-1);
                consulta = conexion.prepareStatement("SELECT * FROM PersonaPuesto WHERE IdPersonalEstructuraOrganizacional=?  AND IdPersonaPuestoSituacion=1");
                consulta.setInt(1, IdPEO);
                
                ArrayList<PersonalEstructuraOrganizacional> puestos = (ArrayList<PersonalEstructuraOrganizacional>) DBTable.select(consulta, PersonaPuesto.class);

                out.print(utilerias.toJson(puestos));

            } catch (Exception e) {
                response.setStatus(400);
                out.print("{\"error\":\"" + e.getMessage() + "\"}");
            }
        } catch (Exception e) {

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

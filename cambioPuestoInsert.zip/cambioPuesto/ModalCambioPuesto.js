
Main.Catalogos = null;
Main.Filtros = null;
Main.Identidad = null;
Main.FiltroActual = null;
Main.ID = null;

Main.load = function (IdPersona) {
    Mensaje.show("Cargando...");
    Head.Script.add("/RecursosHumanos/resources/javascript/Bootstrap.js", true);
    Head.Script.add("/RecursosHumanos/resources/javascript/nachoTools-imp.js", true);
    Head.Script.add("/RecursosHumanos/resources/javascript/Paginador.js", true);
    Head.Script.add("/RecursosHumanos/resources/javascript/Filtro.js", true);
    Head.Script.add("/RecursosHumanos/resources/javascript/JsonCatalogos.js", true);

    Head.Script.run(function () {
        loadTablas();
    });

    function loadTablas() {

        Head.Script.run(function () {
            bootstrap();
        });
    }


    function bootstrap() {
        Bootstrap.loadVersion5r1(function () {
            get("contenedor-index").className = "container-fluid";

            let ajx = new ajaxRequest("/RecursosHumanos/jsonIdentidad");
            ajx.setEventoSuccess(function (responseText) {
                Main.Identidad = JSON.parse(responseText);
                if (!Main.Identidad.IdPerfilSistema) {
                    location.reload();
                }
                Main(IdPersona);
                Mensaje.close();
            });
            ajx.send();
        });
    }


};


class CambioPuesto {

// si tiene el id puesto, asegurar que se envie para el actionGuardar
    constructor(IdPEO, IdPuestoPersona) {
        cargarPEO(IdPEO, IdPuestoPersona);

    }

    generarModalCambioPuesto() {
        let ventana = new ventanita("ventanaCambioPuesto", "gInterfazCambioPuesto");
        ventana.setSize("450px", "780px"); //ABAJO-LADOS
        ventana.setTitulo(`Cambio de puesto`);
        ventana.setFontColorTitulo("#000000");
        ventana.ocultarBotonMinimMaxim(true);
        ventana.setBackgroundColorTitulo("#3d85c6");
        ventana.setBackgroundColor("#ffffff");

        ventana.setTipoBorde("outset");
        ventana.ocultarScrolls(true);
        ventana.setModal(true);


        ventana.setPosicionEnPantalla(ventanita.centrado, ventanita.centrado);
        ventana.setAltoTitulo("50px");


        ventana.setInnerHTML(`
        
                            <div class="container">
                                
                                <div class="row g-2">
                                   <div class="col-6">
                                        <div class="p-3 ">
                                            <label class="form-label" style="font-family: Arial, Helvetica, sans-serif; font-size:15px" id="etiquetaFecha"><strong> Fecha de Aplicación </strong><img src="/RecursosHumanos/resources/iconos/campana.png" style="width:15px; height:15px;"></img><span id= "alertaValidacion"></span></label>
                                            <input type="date" class="form-control shadow bg-body rounded" id="inputFecha">
                                            
                                        </div>
        
                                    </div>
        
                                    <div class="col-6">
                                        <div class="p-3">
                                           <label class="form-label" style="font-family: Arial, Helvetica, sans-serif; font-size:15px"><strong>Puesto Asignado</strong></label>
                                             <div class="input-group" id="buscarPuesto">
                                                <span class="input-group-text" style="background-color:transparent; border: none;"><img src="/RecursosHumanos/resources/iconos/usuarioIcon.png" style="width:25px; height:25px;"></img></span>
                                                <input type="text" class="form-control shadow bg-body rounded" id="inputPuestos" list="listaPuestos" placeholder="Ingresa el nuevo puesto" disabled>
                                            </div>
                                        </div>
                                        
        
                                    </div>
                                   <div class="col-6">
                                        <div class = "p-3">
                                            <label class="form-label" style="font-family: Arial, Helvetica, sans-serif; font-size:15px"><strong>Nivel Administrativo Asignado</strong></label>
                                            <div class="input-group" id="buscarNivel">
                                                <span class="input-group-text" style="background-color:transparent; border: none;"><img src="/RecursosHumanos/resources/iconos/nivel.png" style="width:25px; height:25px;"></img></span>
                                                 <input type="text" class="form-control shadow bg-body rounded" id="inputNiveles" list="listaNiveles" placeholder="Ingresa el nivel administrativo" disabled>
                                            </div>
                                        </div>
                                        
                                    </div>
                                    <div class="col-6">
                                        <div class="p-3">
                                            <label class="form-label" style="font-family: Arial, Helvetica, sans-serif; font-size:15px"><strong>Función Titular Asignado</strong></label>
                                            <div class="input-group" id="buscarFuncion">
                                                <span class="input-group-text" style="background-color:transparent; border: none;"><img src="/RecursosHumanos/resources/iconos/funcionIcon.png" style="width:25px; height:25px;"></img></span>
                                                <input type="text" class="form-control shadow bg-body rounded"  id="inputFunciones" list="listaFunciones" placeholder="Elige una función" disabled>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="p-3 ">
                                              <form method="post" enctype="multipart/form-data" action="#" id="archivo" name="archivo">
                                                    <label class="form-label" style="font-family: Arial, Helvetica, sans-serif; font-size:15px"><strong>Archivo correspondiente</strong></label>
                                                    <input class="form-control" type="file" id="inputArchivo" name="archivo" accept=".pdf,.docx" disabled>
                                               </form>
                                        </div>
                                    </div>
                                    <div class="col-6">
        
                                         <div class="d-flex justify-content-center" id="divBtnGuardar">
                                        <button class="btn btn-success mt-3" id="btnGuardar" disabled>Guardar</button>
                                    </div>
                                    </div>
                                </div>
                            </div>
        
    `);

        ventana.show();
        listas();
    }

    cancelarPuesto() {

    }

    modificarPuesto() {}

    cerrarModalCambioPuesto() {
        let modalCambioPuesto = new ventanita("ventanaCambioPuesto", "gInterfazCambioPuesto");
        modalCambioPuesto.cerrar();
    }

}

// Cargar los datos PEO del Id proporcionado para validar la fecha de vencimiento
let datosPEO;
let IdPersonaPuesto;
var IdPersona = 0;
function cargarPEO(peo_id, puestopersona_id) {
    IdPEO = peo_id;
    IdPersonaPuesto = puestopersona_id; // conservamos el id persona puesto porque indica una modificacion

    let ajx = new ajaxRequest("/RecursosHumanos/personal.gestion.cambioPuesto/JsonPEO", "IdPEO=" + peo_id);
    ajx.setEventoSuccess(function (responseText) {
        datosPEO = JSON.parse(responseText);
        IdPersona = datosPEO[0].IdPersona;
        // Enviar el id plantilla e id peo para validar al usuario
        JsonValidacionesPrincipales(datosPEO[0].IdPersonaPlantilla, datosPEO[0].IdPersona, peo_id);

    });
    ajx.setEventoFail(function (responseText) {
        alert(responseText);
        return;
    });
    ajx.send();
}

let puestosActivos;
function cargarPuestosActivos(peo_id) {
    let ajx = new ajaxRequest("/RecursosHumanos/personal.gestion.cambioPuesto/JsonPuestos", "IdPEO=" + peo_id);
    ajx.setEventoSuccess(function (responseText) {
        puestosActivos = JSON.parse(responseText);

        calendario(puestosActivos);
        descripcionSecuenciaProceso(puestosActivos);


    });
    ajx.setEventoFail(function (responseText) {
        alert(responseText);
        return;
    });
    ajx.send();
}



// Funcion que valida que NO sea docente, que tenga una adscripcion activa, una definitividad activa (incluyendo solo 1 categoria activa, no mas) y el IdPEO reciente
let validacionesPrincipales;
function JsonValidacionesPrincipales(plantilla_id, IdPersona, IdPEO) {
    let ajx = new ajaxRequest("/RecursosHumanos/personal.gestion.cambioPuesto/JsonValidacionesPrincipales", "IdPlantilla=" + plantilla_id + "&IdPersona=" + IdPersona + "&IdPEO=" + IdPEO);
    ajx.setEventoSuccess(function (responseText) {
        validacionesPrincipales = JSON.parse(responseText);
        alertaIncumplimiento(validacionesPrincipales);

    });
    ajx.setEventoFail(function (responseText) {
        alert(responseText);
        return;
    });
    ajx.send();

}

var IdPEOValido = 0;
function alertaIncumplimiento(validaciones) {
    var mensajes = [];

    if (!validaciones.noEsDocente) {
        mensajes.push("Es un docente");
        alertaCorrecion(mensajes);
    }
    if (!validaciones.adscripcionActiva) {
        mensajes.push("No tiene una adscripción activa");
        alertaCorrecion(mensajes);
    }
    /* if (!validaciones.definitividadActiva) {
     mensajes.push("No tiene una definitividad activa o tiene más de una categoría activa actualmente");
     alertaCorrecion(mensajes);
     }*/
    if (validaciones.IdPEOReciente != datosPEO[0].IdPersonalEstructuraOrganizacional) {
        alertaIdPEO();
    }
    IdPEOValido = validaciones.IdPEOReciente;
    cargarPuestosActivos(IdPEOValido);

}


var puestoElegido = 0, nivelElegido = 0, funcionElegida = 0;
function listas() {

    let inputPuestos = document.getElementById("inputPuestos");
    let datalistPuestos = new Datalist(inputPuestos, "/RecursosHumanos/personal.gestion/cambioPuesto/JsonTipoPersonal", "IdTipoPersona", "Nombre", "Nombre");
    datalistPuestos.onSelect = function (puesto) {
        puestoElegido = puesto.IdTipoPersona;
    };
    datalistPuestos.activate();

    let inputNiveles = document.getElementById("inputNiveles");
    let datalistNiveles = new Datalist(inputNiveles, "/RecursosHumanos/personal.gestion/cambioPuesto/JsonNivelesUnidadAdministrativa", "IdNivelUnidadAdministrativa", "UnidadAdministrativa", "UnidadAdministrativa");
    datalistNiveles.onSelect = function (nivel) {
        nivelElegido = nivel.IdNivelUnidadAdministrativa;
    };
    datalistNiveles.activate();

    let inputFunciones = document.getElementById("inputFunciones");
    let datalistFunciones = new Datalist(inputFunciones, "/RecursosHumanos/personal.gestion/cambioPuesto/JsonPuestoTitularidad", "IdPuestoTitularidad", "NombreTitularidad", "NombreTitularidad");
    datalistFunciones.onSelect = function (titularidad) {
        funcionElegida = titularidad.IdPuestoTitularidad;
    };
    datalistFunciones.activate();

    guardar();

}

// Analizar cuantos puestos activos tiene o futuros, para definir que situación tiene al requerir un nuevo puesto 
var fecha = null;
var banderaPuestos = 0;
function calendario(puestos) {
    // fechas tipo dd-MM-yy
    let fechaAsignada = null;
    let fechaVencimiento = null;

    if (puestos.length >= 1) {
        banderaPuestos = 1;

    } else {

        banderaPuestos = 0;

    }
    // si la fecha causa conflicto se le notifica por alerta y se mantienen deshabilitados los input
    let fechaAplicacion = document.getElementById("inputFecha");

    fechaAplicacion.onchange = function () {
        fecha = fechaAplicacion.value;
        validarFechas(fecha, puestos, banderaPuestos)
                .then(function (result) {
                    if (fechaAplicacion.value == "") {
                        bagde(0);
                    } else {
                        if (result != true) { // puede guardar
                            bagde(1);

                        } else {// No se cumple la condición, pintar el aviso 
                            bagde(0);
                        }
                    }

                })
                .catch(function (error) {
                    // Manejar errores aquí
                    console.error(error);
                });
    };
}

function bagde(bandera) {

    let labelFecha = document.getElementById("etiquetaFecha");

    let span = document.getElementById("alertaValidacion");
    let btnGuardar = document.getElementById("btnGuardar");

    let inputPuestos = document.getElementById("inputPuestos");
    let inputNiveles = document.getElementById("inputNiveles");
    let inputFunciones = document.getElementById("inputFunciones");
    let inputArchivo = document.getElementById("inputArchivo");

    if (bandera != 0) { // es valido
        span.setAttribute("class", "badge rounded-pill bg-success");
        span.innerHTML = " ES VÁLIDA";
        inputPuestos.removeAttribute("disabled");
        inputFunciones.removeAttribute("disabled");
        inputNiveles.removeAttribute("disabled");
        inputArchivo.removeAttribute("disabled");

        btnGuardar.removeAttribute("disabled");

    } else { // no es valido
        span.setAttribute("class", "badge rounded-pill bg-danger");
        span.innerHTML = " NO ES VÁLIDA";
        inputPuestos.textContent = "";
        inputPuestos.setAttribute("disabled", true);
        inputFunciones.setAttribute("disabled", true);
        inputNiveles.setAttribute("disabled", true);
        inputArchivo.setAttribute("disabled", true);

        btnGuardar.setAttribute("disabled", true);
    }

    labelFecha.appendChild(span);
}


function validarFechas(fechaAplicacion, puestos, bandera) {
    let contador = 0;
    let fechaFinal = null;
    let fechaAsignacion = null;

    return new Promise(function (resolve, reject) {
        if (puestos.length == 0) {
            resolve(false);
        } else {
            for (let i = 0; i < puestos.length; i++) {
                if (puestos[i].FechaFinal != undefined) {
                    fechaFinal = puestos[i].FechaFinal;
                }
                if (puestos[i].FechaAsignacion != undefined) {
                    fechaAsignacion = puestos[i].FechaAsignacion;
                }
                let ajx = new ajaxRequest("/RecursosHumanos/personal.gestion.cambioPuesto/JsonValidarEventos", "fechaFinal=" + fechaFinal + "&fechaAsignada=" + fechaAsignacion + "&fechaAplicacion=" + fechaAplicacion + "&bandera=" + bandera);
                ajx.setEventoSuccess(function (responseText) {
                    let respuesta = JSON.parse(responseText);

                    if (respuesta == false) {
                        contador++;

                        if (contador == puestos.length) {

                            resolve(false); // indica que termino y que en efecto, ninguno coincide y podra guardar
                        }
                    } else { // indica que termino y que en efecto,  coincide con alguno y no podra guardar

                        resolve(true);
                    }

                });
                ajx.setEventoFail(function (responseText) {
                    reject(false);
                });
                ajx.send();
            }
        }

    });

}

function guardar() {

    document.getElementById("btnGuardar").onclick = function () {
        let inputPuestos = document.getElementById("inputPuestos");
        let inputNiveles = document.getElementById("inputNiveles");
        let inputFunciones = document.getElementById("inputFunciones");
        let inputArchivo = document.getElementById("inputArchivo");

        let inputs = [inputPuestos, inputNiveles, inputFunciones, inputArchivo];
        let algunoVacio = false;

        // Verificar si algún input está vacío
        inputs.forEach(function (input) {
            if (input.value === "") {
                input.style.borderColor = "red";
                algunoVacio = true;
            } else {
                input.style.borderColor = ""; // Restablecer el color del borde si no está vacío
            }
        });

        // Si algún input está vacío, no invocar alertaRegistrar
        if (algunoVacio) {
            return; // Salir de la función
        }

        // Si todos los campos están llenos, invocar alertaRegistrar
        //console.log("HOLA");
        alertaRegistrar(banderaPuestos, fecha, puestoElegido, nivelElegido, funcionElegida);
    };

}


function alertaCorrecion(mensajes) {
    let modalCambioPuesto = new ventanita("ventanaCambioPuesto", "gInterfazCambioPuesto");
    modalCambioPuesto.cerrar();
    const mensajeHTML = mensajes.map(mensaje => `<p style = " text-align: justify;"><img src="/RecursosHumanos/resources/iconos/alerta.png" style="height:30px; weight:30px"><img>${mensaje}</p>`).join('');
    const swalWithBootstrapButtons = Swal.fire({
        title: "Atención",
        html: `<p style = "font-weight:bold ; color: red;">No esta disponible para cambiar el puesto</p>` + mensajeHTML

    });
}

function alertaIdPEO() {
    const swalWithBootstrapButtons = Swal.fire({
        icon: "warning",
        title: "Atención",
        text: "El IdPEO recibido de la persona  no es el más reciente, por ello; hemos buscado el correcto para hacer el cambio sobre él."
    });
}


function alertaRegistrar(bandera, fechaAplicacion, puesto, nivel, funcion) {
    const swalWithBootstrapButtons = Swal.mixin({
        customClass: {
            confirmButton: "btn btn-success",
            cancelButton: "btn btn-danger"
        },
        buttonsStyling: true
    });
    swalWithBootstrapButtons.fire({
        title: "¿Estás seguro de cambiar el puesto?",
        html: `<p style = "font-weight:bold ; color: red;">Se dará de baja el puesto actual para asignar un nuevo puesto</p>`,
        icon: "question",
        showCancelButton: true,
        confirmButtonText: "Si, estoy seguro",
        cancelButtonText: "No, cancelar",
        reverseButtons: true
    }).then((result) => {
        if (result.isConfirmed) {
            //alert(archivo.value);
            actionGuardarPuesto(bandera, fechaAplicacion, puesto, nivel, funcion);
            swalWithBootstrapButtons.fire({
                title: "Bien hecho",
                text: "El puesto ha sido asignado.",
                icon: "success"
            });
            let modalCambioPuesto = new ventanita("ventanaCambioPuesto", "gInterfazCambioPuesto");
            modalCambioPuesto.cerrar();
        } else if (
                /* Read more about handling dismissals below */
                result.dismiss === Swal.DismissReason.cancel
                ) {
            swalWithBootstrapButtons.fire({
                title: "Cancelar",
                text: "El cambio ha sido cancelado",
                icon: "error"
            });
        }
    });
}


// la bandera servira para saber si tiene que desactivar los puestos anteriores o no
function actionGuardarPuesto(bandera, fechaAplicacion, puesto, nivel, funcion) {
    let inputArchivo = document.getElementById("inputArchivo");

    var form_data = new FormData();
    form_data.append("archivo", inputArchivo.files[0]);
    form_data.append("bandera", bandera);
    form_data.append("IdPEO", IdPEOValido);
    form_data.append("IdPersona", IdPersona);
    form_data.append("fechaAplicacion", fechaAplicacion);
    form_data.append("puesto", puesto);
    form_data.append("nivel", nivel);
    form_data.append("funcion", funcion);
    form_data.append("descripcion", descripcion);
    let ajx = new ajaxRequest("/RecursosHumanos/personal.gestion.cambioPuesto/ActionGuardarCambioPuesto");
    ajx.setFormData(form_data);

    ajx.setEventoSuccess(function (responseText) {
        cargarPuestosActivos(IdPEOValido);

    });
    ajx.setEventoFail(function (responseText) {
        alert(responseText);
        return;
    });
    ajx.send();
}

function actionCancelarPuesto(peo_id, personaPuesto_id) {

}


// desglosa los puestos activos porque si hay un cambio de puesto, se modificaran y se necesitan por si hay una cancelacion, regresamos todo 
let descripcion = "";
function descripcionSecuenciaProceso(puestos) {

    var obj = new Object();
    obj.IdPersonaPuesto = [];
    obj.FechaAsignacion = [];
    obj.FechaFinal = [];
    obj.IdPersonaPuestoSituacion = [];

    for (let i = 0; i < puestos.length; i++) {
        obj.IdPersonaPuesto[i] = puestos[i].IdPersonaPuesto;
        obj.FechaAsignacion[i] = puestos[i].FechaAsignacion;
        obj.FechaFinal[i] = puestos[i].FechaFinal;
        obj.IdPersonaPuestoSituacion[i] = puestos[i].IdPersonaPuestoSituacion;
        //convert object to json string
        var string = JSON.stringify(obj);
    }
    descripcion = string;
}


<?php
include 'jugador.php';
include 'dado.php';
include 'jugada.php';


class juego{
    
    public int $cantidadJugadas, $marcadorJ1, $marcadorJ2;
    private bool $bandJugador;
    public jugador $jugador1;
    public jugador $jugador2;
    
    public jugador $vencedor;

    public dado $dado1;
    public dado $dado2;

    public function __construct($nombreJ1,$nombreJ2){         
      
        $this->jugador1 = new jugador;
        $this->jugador1->nombre = $nombreJ1;
        $this->jugador2 = new jugador;
        $this->jugador2->nombre = $nombreJ2;

    }

    public function elegirPrimerLanzador():void{
        if ((int) (rand()*(3-1)==1)) {
            # code...
            $this->bandJugador = true; // jugador 1
        } else {
            # code...
            $this->bandJugador = false; //jugador 2
        }
        
    }

    public function iniciarJugada():void{
        $jugada = new jugada;

        if ($this->bandJugador) {
            # code...
            $jugada->iniciarJugada($this->jugador1, $this->jugador2,$this->dado1,$this->dado2);
        } else {
            # code...
            $jugada->iniciarJugada($this->jugador2, $this->jugador1,$this->dado1,$this->dado2);
        }

        $this->marcadorJ1 = $this->marcadorJ1 + $this->jugador1->puntoGanado;
        $this->marcadorJ2 = $this->marcadorJ2 + $this->jugador2->puntoGanado;
    }

    public function iniciarJuego():void{
        $this->dado1 = new dado();
        $this->dado2 = new dado();

        $this->cantidadJugadas = 0;
        $this->marcadorJ1 = 0;
        $this->marcadorJ2 = 0;

        $this->elegirPrimerLanzador();

        do{
            $this->iniciarJugada();
            $this->cantidadJugadas++;

        }while (($this->marcadorJ1 != 5) && ($this->marcadorJ2 != 5));
            # code...
            $this->vencedor = $this-> determinarVencedor();
        

    }

    public function  determinarVencedor(){
        if (($this->marcadorJ1 == 5) && ($this->marcadorJ2 == 5))
            # code...
            return null;

        if ($this->marcadorJ1 == 5) {
            # code...
            return $this->jugador1;
        } else {
            # code...
            if ($this->marcadorJ2 == 5) {
                # code...
                return $this->jugador2;
            }
        }
        return null;    
    }






}
?>
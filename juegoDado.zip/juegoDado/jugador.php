<?php 

class jugador{
    public string $nombre;
    public int $puntoGanado;

    public function lanzaDados(Dado $dado1, Dado $dado2){
        $dado1->lanzar(); 
        $dado2->lanzar();
        return (int) ($dado1->puntos + $dado2->puntos);
    }

    public function __construct(){
        $this -> puntoGanado = 0;
    }
    
}

?>
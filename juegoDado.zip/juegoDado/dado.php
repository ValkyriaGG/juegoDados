<?php

class dado{
    public int $puntos;

    public function lanzar():void{
        $this->puntos = rand(1,6);
        
    }

    public function __construct(){
        $this-> puntos = 0;
    }
}
 //crear
/*  $midado = new dado();
 $midado->lanzar();
 echo 'Puntos: '.$midado->puntos;

 //finalizar 
 
$midado = null; */
 
?>
<?php

class jugada{
    public int $puntosJ1, $puntosJ2;
    public function iniciarJugada(jugador $jugador1, jugador $jugador2,Dado $d1, Dado $d2){
        $this->puntosJ1 = $this->turnarJugador($jugador1,$d1,$d2);
        $this->puntosJ2 = $this->turnarJugador($jugador2,$d1,$d2);

        $this->determinarGanador($jugador1,$this->puntosJ1,$jugador2,$this->puntosJ2);
        
    }

    private function turnarJugador(jugador $jugadorEnTurno, Dado $d1, Dado $d2){
        return $jugadorEnTurno->lanzaDados($d1,$d2);
    }

    public function determinarGanador(jugador $j1,  int $pJ1,jugador $j2, int $pJ2 ):void{
        if ($pJ1 == 7) {
            # code...
            $j1->puntoGanado = 1;
        } else {
            # code...
            $j1->puntoGanado = 0;
        }

        if ($pJ2 == 7) {
            # code...
            $j2->puntoGanado = 1;
        } else {
            # code...
            $j2->puntoGanado = 0;
        }
        
    }



}



?>